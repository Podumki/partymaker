<?php

namespace app\models;

use yii\db\ActiveRecord;

class Modes extends ActiveRecord
{
}