<?php

namespace app\models;

use yii\db\ActiveRecord;

class AchievmentType extends ActiveRecord
{
}