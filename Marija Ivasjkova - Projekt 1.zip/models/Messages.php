<?php

namespace app\models;

use yii\db\ActiveRecord;

class Messages extends ActiveRecord
{
}