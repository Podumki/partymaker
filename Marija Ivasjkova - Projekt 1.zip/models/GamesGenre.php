<?php

namespace app\models;

use yii\db\ActiveRecord;

class GamesGenre extends ActiveRecord
{
}