<?php

namespace app\models;

use yii\db\ActiveRecord;

class Userachievment extends ActiveRecord
{
}