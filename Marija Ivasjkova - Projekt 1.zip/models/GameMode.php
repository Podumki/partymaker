<?php

namespace app\models;

use yii\db\ActiveRecord;

class GameMode extends ActiveRecord
{
}