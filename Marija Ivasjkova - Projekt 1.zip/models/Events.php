<?php

namespace app\models;

use yii\db\ActiveRecord;

class Events extends ActiveRecord
{
}