<?php

namespace app\models;

use yii\db\ActiveRecord;

class GameAchievment extends ActiveRecord
{
}