<?php

namespace app\models;

use yii\db\ActiveRecord;

class Achievments extends ActiveRecord
{
}