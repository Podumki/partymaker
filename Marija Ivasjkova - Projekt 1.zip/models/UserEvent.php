<?php

namespace app\models;

use yii\db\ActiveRecord;

class UserEvent extends ActiveRecord
{
}