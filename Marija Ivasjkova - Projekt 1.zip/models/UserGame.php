<?php

namespace app\models;

use yii\db\ActiveRecord;

class UserGame extends ActiveRecord
{
}